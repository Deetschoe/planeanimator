from . import generate_frame

def register(): generate_frame.register()
def unregister(): generate_frame.unregister()